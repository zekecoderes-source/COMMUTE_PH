(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s)};
var esc=function(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})};
var peso=function(n){return "₱"+(Math.round(n*100)/100).toFixed(2)};
var clone=function(o){return JSON.parse(JSON.stringify(o))};

/* ---------- icons ---------- */
var A='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
var IC={
  trad:A+'<rect x="2" y="7" width="20" height="9" rx="2"/><path d="M2 12h20M8 7v5M14 7v5"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/></svg>',
  modern:A+'<rect x="2" y="6" width="20" height="10" rx="3.5"/><path d="M2 11h20M7 6v5M12 6v5M17 6v5"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/></svg>',
  trike:A+'<circle cx="6" cy="17" r="2.2"/><circle cx="18" cy="17" r="2.2"/><path d="M8 17h6l3-7h-5l-2 4M12 10l-1-3H9"/></svg>',
  bus:A+'<rect x="3" y="4" width="18" height="13" rx="2.5"/><path d="M3 10h18M8 4v6M16 4v6"/><circle cx="8" cy="19.5" r="1.5"/><circle cx="16" cy="19.5" r="1.5"/></svg>',
  other:A+'<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>',
  home:A+'<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/></svg>',
  route:A+'<circle cx="6" cy="18" r="2.2"/><circle cx="18" cy="6" r="2.2"/><path d="M8.2 18H15a3 3 0 0 0 0-6H9a3 3 0 0 1 0-6h6.8"/></svg>',
  fare:A+'<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 12h2M12 12h4M8 16h2M12 16h4"/></svg>',
  pin:A+'<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.4"/></svg>',
  wallet:A+'<path d="M4 7h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M4 7l11-3v3M16 14h2"/></svg>',
  gear:A+'<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/></svg>',
  swap:A+'<path d="M7 4v14M7 18l-3-3M7 18l3-3M17 20V6M17 6l-3 3M17 6l3 3"/></svg>',
  info:A+'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
  search:A+'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/></svg>'
};
$("#gear").innerHTML=IC.gear;

var MODES=window.BIYAHE.MODES,MODE_KEYS=BIYAHE.MODE_KEYS,PLACES=BIYAHE.PLACES,ROUTES=BIYAHE.ROUTES,DEFAULT_RATES=BIYAHE.DEFAULT_RATES,FARE_TYPES=BIYAHE.FARE_TYPES;
var DAY=864e5;

/* ---------- state ---------- */
var KEY="biyahe-sorsogon-v1";
function dkey(d){var m=d.getMonth()+1,dd=d.getDate();return d.getFullYear()+"-"+(m<10?"0":"")+m+"-"+(dd<10?"0":"")+dd}
function daysAgo(n){return dkey(new Date(Date.now()-n*DAY))}
function seedExpenses(){
  var rows=[[0,"trad",13,"Cabid-an to Pier"],[0,"trike",22,"Pier to City Hall"],[1,"modern",33.75,"Bacon to Cabid-an"],[1,"trike",15,"Hospital to Capitol"],[2,"trad",28.25,"Bacon to Cabid-an"],[3,"trad",13,"Cabid-an to Pier"],[4,"bus",37,"Cabid-an to Gubat"]];
  return rows.map(function(r,i){return {id:"s"+i,date:daysAgo(r[0]),mode:r[1],amount:r[2],note:r[3],sample:true}});
}
function freshState(){
  return {
    profile:{name:"",fareType:"regular",budget:150},
    rates:clone(DEFAULT_RATES),
    from:"",to:"",mode:"all",sort:"fare",
    saved:[{id:"sv1",label:"School",place:"ssu",sample:true},{id:"sv2",label:"Work",place:"capitol",sample:true}],
    expenses:seedExpenses(),
    calc:{km:5,pax:1}
  };
}
var S=freshState();
try{
  var raw=localStorage.getItem(KEY);
  if(raw){var p=JSON.parse(raw);if(p&&typeof p==="object"){
    ["profile","rates","calc"].forEach(function(k){if(p[k])S[k]=Object.assign(S[k],p[k])});
    ["from","to","mode","sort"].forEach(function(k){if(typeof p[k]==="string")S[k]=p[k]});
    if(Array.isArray(p.saved))S.saved=p.saved;
    if(Array.isArray(p.expenses))S.expenses=p.expenses;
  }}
}catch(e){}
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}if(user)queuePush()}
var confirmReset=false;

/* ---------- account sync (Flask + SQLite backend) ---------- */
var user=null,pushTimer=null;
function api(method,url,body){
  return fetch(url,{method:method,headers:body?{"Content-Type":"application/json"}:{},body:body?JSON.stringify(body):undefined,credentials:"same-origin"})
    .then(function(r){return r.json().catch(function(){return {}}).then(function(j){if(!r.ok)throw new Error(j.error||"Request failed");return j})});
}
function cleanState(){
  return {profile:S.profile,rates:S.rates,
    saved:S.saved.filter(function(x){return !x.sample}),
    expenses:S.expenses.filter(function(x){return !x.sample})};
}
function queuePush(){
  clearTimeout(pushTimer);
  pushTimer=setTimeout(function(){api("PUT","/api/me/state",cleanState()).catch(function(){toast("Could not sync to your account")})},600);
}
function applyServer(st){
  if(!st)return;
  if(st.profile)S.profile=Object.assign(S.profile,st.profile);
  if(st.rates)S.rates=Object.assign(S.rates,st.rates);
  S.saved=st.saved||[];S.expenses=st.expenses||[];
  try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){}
}
function loadMe(){
  api("GET","/api/me").then(function(j){if(j.user){user=j.user;applyServer(j.state);rerender()}}).catch(function(){});
}
function auth(mode){
  var body={email:$("#a-email").value.trim(),password:$("#a-pass").value,name:$("#a-name").value.trim()};
  if(mode==="register")body.state=cleanState();
  api("POST","/api/"+mode,body).then(function(j){
    user=j.user;applyServer(j.state);rerender();toast(mode==="register"?"Account created":"Signed in");
  }).catch(function(e){toast(e.message)});
}
function logout(){
  api("POST","/api/logout",{}).then(function(){user=null;S=freshState();save();rerender();toast("Signed out")}).catch(function(){toast("Could not sign out")});
}
function authCard(){
  if(user){
    return '<div class="card"><h3 style="margin-bottom:6px">Your account</h3><p class="small muted" style="margin-bottom:12px">Signed in as <b>'+esc(user.email)+'</b>. Saved places, expenses and settings sync to the database.</p><button class="btn" data-act="logout">Sign out</button></div>';
  }
  return '<form class="card" data-form="auth"><h3 style="margin-bottom:6px">Account (optional)</h3><p class="small muted" style="margin-bottom:12px">Sign in to keep your saved places and expenses in the database. Without an account they stay in this browser.</p>'+
    '<div class="row"><div class="field"><label for="a-email">Email</label><input id="a-email" type="text" inputmode="email" autocomplete="email"></div>'+
    '<div class="field"><label for="a-pass">Password</label><input id="a-pass" type="password" autocomplete="current-password" minlength="8"></div></div>'+
    '<div class="row" style="margin-top:10px"><div class="field"><label for="a-name">Name (new accounts)</label><input id="a-name" type="text" maxlength="30" autocomplete="name"></div></div>'+
    '<div class="row" style="margin-top:12px"><button class="btn primary" type="submit" data-mode="login">Sign in</button><button class="btn" type="submit" data-mode="register">Create account</button></div></form>';
}

/* ---------- logic ---------- */
function placeName(id){for(var i=0;i<PLACES.length;i++)if(PLACES[i].id===id)return PLACES[i].name;return id}
function fare(mode,km){
  var r=S.rates[mode]||DEFAULT_RATES[mode];if(!r)return 0;
  var raw=Number(r.base)+Math.max(0,km-Number(r.baseKm))*Number(r.perKm);
  var disc=S.profile.fareType==="regular"?1:0.8;
  return Math.round(raw*disc*4)/4;
}
function kmBetween(r,a,b){
  if(a===b)return null;var sa=null,sb=null;
  r.stops.forEach(function(s){if(s[0]===a)sa=s;if(s[0]===b)sb=s});
  return sa&&sb?Math.abs(sa[1]-sb[1]):null;
}
function direct(a,b,mode){
  var out=[];
  ROUTES.forEach(function(r){
    if(mode!=="all"&&r.mode!==mode)return;
    var km=kmBetween(r,a,b);
    if(km!=null)out.push({r:r,from:a,to:b,km:km,fare:fare(r.mode,km)});
  });
  return out;
}
function transfers(a,b,mode){
  var best={};
  ROUTES.forEach(function(r1){
    if(mode!=="all"&&r1.mode!==mode)return;
    if(!r1.stops.some(function(s){return s[0]===a}))return;
    ROUTES.forEach(function(r2){
      if(r1===r2||(mode!=="all"&&r2.mode!==mode))return;
      if(!r2.stops.some(function(s){return s[0]===b}))return;
      r1.stops.forEach(function(s){
        var m=s[0];if(m===a||m===b)return;
        var k1=kmBetween(r1,a,m),k2=kmBetween(r2,m,b);
        if(k1==null||k2==null)return;
        var o={legs:[{r:r1,from:a,to:m,km:k1,fare:fare(r1.mode,k1)},{r:r2,from:m,to:b,km:k2,fare:fare(r2.mode,k2)}]};
        o.km=k1+k2;o.fare=o.legs[0].fare+o.legs[1].fare;
        var key=r1.id+">"+r2.id;
        if(!best[key]||best[key].km>o.km)best[key]=o;
      });
    });
  });
  return Object.keys(best).map(function(k){return best[k]}).sort(function(x,y){return x.fare-y.fare}).slice(0,4);
}
function sortFn(){return S.sort==="km"?function(x,y){return x.km-y.km||x.fare-y.fare}:function(x,y){return x.fare-y.fare||x.km-y.km}}
function todayKey(){return dkey(new Date())}
function spentOn(k){return S.expenses.reduce(function(t,e){return e.date===k?t+Number(e.amount):t},0)}
function uid(){return "u"+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function toast(msg){var t=$("#toast");t.textContent=msg;t.classList.add("on");clearTimeout(toast.t);toast.t=setTimeout(function(){t.classList.remove("on")},2300)}
function addExpense(o){S.expenses.unshift({id:uid(),date:o.date||todayKey(),mode:o.mode,amount:o.amount,note:o.note||""});save()}

/* ---------- shared fragments ---------- */
function placeSelect(id,val,label,blank){
  var h='<div class="field"><label for="'+id+'">'+label+'</label><select id="'+id+'" data-bind="'+(id.indexOf("from")>-1?"from":"to")+'"><option value="">'+blank+'</option>';
  PLACES.forEach(function(p){h+='<option value="'+p.id+'"'+(p.id===val?" selected":"")+'>'+esc(p.name)+'</option>'});
  return h+"</select></div>";
}
function planner(suffix){
  return '<div class="row">'+placeSelect("from-"+suffix,S.from,"From","Choose origin")+
    '<button class="btn swap" data-act="swap" aria-label="Swap origin and destination">'+IC.swap+'</button>'+
    placeSelect("to-"+suffix,S.to,"To","Choose destination")+'</div>';
}
function badge(mode){var m=MODES[mode];return '<span class="badge '+m.c+'">'+IC[mode]+m.name+'</span>'}
function rateText(mode){var r=S.rates[mode];return peso(r.base)+" for the first "+r.baseKm+" km, then "+peso(r.perKm)+" per km"}
function sampleNotice(text){return '<div class="notice">'+IC.info+'<div>'+text+'</div></div>'}

/* ---------- views ---------- */
function renderHome(){
  var t=spentOn(todayKey()),b=Number(S.profile.budget)||0,pct=b>0?Math.min(100,t/b*100):0;
  var cls=t>b?"over":(t>b*0.8?"warn":"");
  var hr=new Date().getHours(),greet=hr<12?"Magandang umaga":(hr<18?"Magandang hapon":"Magandang gabi");
  var name=S.profile.name?", "+esc(S.profile.name):"";
  var h='<div><h2>'+greet+name+'</h2><p class="muted">Where are you headed today?</p></div>';
  h+='<div class="card"><div class="lbl" style="margin-bottom:10px">Plan a trip</div>'+planner("home")+
     '<div style="margin-top:12px"><button class="btn primary" style="width:100%" data-act="find">'+IC.search+'Find routes</button></div>';
  if(S.saved.length){
    h+='<div style="margin-top:14px"><div class="lbl" style="margin-bottom:8px">Saved destinations</div><div class="chips">';
    S.saved.forEach(function(s){h+='<button class="chip" data-act="pickdest" data-place="'+s.place+'">'+IC.pin.replace('<svg','<svg width="14" height="14"')+esc(s.label)+'</button>'});
    h+='</div></div>';
  }
  h+='</div>';
  h+='<div><div class="head" style="margin-bottom:10px"><h3>Ways to get around</h3><span class="small muted">Sample routes</span></div><div class="modes">';
  MODE_KEYS.forEach(function(k){
    var n=ROUTES.filter(function(r){return r.mode===k}).length;
    h+='<button class="mode '+MODES[k].c+'" data-act="mode" data-mode="'+k+'"><span class="ic">'+IC[k]+'</span><b>'+MODES[k].name+'</b><span>'+n+' sample route'+(n>1?"s":"")+' · from '+peso(fare(k,0.1))+'</span></button>';
  });
  h+='</div></div>';
  h+='<div class="card"><div class="head"><h3>Today’s transport spend</h3><button class="btn ghost sm" data-go="budget">Open tracker</button></div>'+
     '<div class="big num" style="margin-top:8px">'+peso(t)+' <span class="small muted" style="font-family:var(--font-body);font-weight:500">of '+peso(b)+'</span></div>'+
     '<div class="meter" style="margin:10px 0 6px"><i class="'+cls+'" style="width:'+pct+'%"></i></div>'+
     '<div class="small muted num">'+(t>b?peso(t-b)+" over your daily budget":peso(b-t)+" left today")+'</div></div>';
  h+=sampleNotice('<b>Sample information.</b> Routes, stops, distances and fares here are examples for building the app. They are not verified and no vehicle is tracked live. See the status list in Profile.');
  $("#p-home").innerHTML=h;
}

function stopList(r,from,to){
  var lo=1e9,hi=-1;
  r.stops.forEach(function(s){if(s[0]===from||s[0]===to){lo=Math.min(lo,s[1]);hi=Math.max(hi,s[1])}});
  var h='<ol class="stops '+MODES[r.mode].c+'">';
  r.stops.forEach(function(s){
    var on=from&&s[1]>=lo&&s[1]<=hi;
    var tg=s[0]===from?'<span class="tag">Board</span>':(s[0]===to?'<span class="tag">Alight</span>':'<span class="km num">'+s[1]+' km</span>');
    h+='<li class="'+(on?"on":"")+'"><span></span><span>'+esc(placeName(s[0]))+'</span>'+tg+'</li>';
  });
  return h+"</ol>";
}
function routeCard(x,open){
  var r=x.r;
  return '<details class="route '+MODES[r.mode].c+'"'+(open?" open":"")+'><summary><span class="rico">'+IC[r.mode]+'</span>'+
    '<span><span class="rname">'+esc(r.name)+'</span><span class="meta"><span>'+MODES[r.mode].name+'</span><span class="num">'+x.km.toFixed(1)+' km</span></span></span>'+
    '<span class="fare num">'+peso(x.fare)+'<small>est. per person</small></span></summary>'+
    '<div class="rbody">'+stopList(r,x.from,x.to)+
    '<div class="meta"><span>'+esc(r.via)+'</span><span>Frequency: '+r.freq+' (sample)</span><span>Hours: '+r.hours+' (sample)</span></div>'+
    '<div class="row"><button class="btn primary sm" data-act="log" data-r="'+r.id+'" data-a="'+x.from+'" data-b="'+x.to+'">Log this trip</button></div></div></details>';
}
function renderRoutes(){
  var h='<div><h2>Find a route</h2><p class="muted">Pick where you are and where you are going.</p></div>';
  h+='<div class="card">'+planner("routes")+'</div>';
  h+='<div class="chips" role="group" aria-label="Filter by transport">';
  [["all","All"]].concat(MODE_KEYS.map(function(k){return [k,MODES[k].name]})).forEach(function(m){
    h+='<button class="chip" data-act="mode" data-mode="'+m[0]+'" aria-pressed="'+(S.mode===m[0])+'">'+m[1]+'</button>';
  });
  h+='</div>';
  h+='<div class="row" style="align-items:center"><div class="field" style="flex:0 1 220px"><label for="sort">Sort by</label><select id="sort" data-bind="sort"><option value="fare"'+(S.sort==="fare"?" selected":"")+'>Lowest fare</option><option value="km"'+(S.sort==="km"?" selected":"")+'>Shortest distance</option></select></div></div>';
  if(S.from&&S.to&&S.from!==S.to){
    var d=direct(S.from,S.to,S.mode).sort(sortFn());
    h+='<div class="head"><h3>'+esc(placeName(S.from))+' → '+esc(placeName(S.to))+'</h3><button class="btn ghost sm" data-act="savedest">Save destination</button></div>';
    if(d.length){
      h+='<div class="small muted">'+d.length+' direct sample route'+(d.length>1?"s":"")+'. Fares use your '+FARE_TYPES[S.profile.fareType].toLowerCase()+' rate.</div><div class="list">';
      d.forEach(function(x,i){h+=routeCard(x,i===0)});
      h+='</div>';
    }else{
      var tr=transfers(S.from,S.to,S.mode);
      if(tr.length){
        h+='<div class="small muted">No direct sample route. These options need one transfer.</div><div class="list">';
        tr.forEach(function(o){
          h+='<div class="card"><div class="head"><b>Transfer at '+esc(placeName(o.legs[0].to))+'</b><span class="fare num" style="font-size:1.15rem">'+peso(o.fare)+'</span></div><div class="list" style="margin-top:10px">';
          o.legs.forEach(function(l,i){
            h+='<div class="leg '+MODES[l.r.mode].c+'"><div>'+badge(l.r.mode)+'</div><div class="rname" style="margin-top:4px">'+esc(l.r.name)+'</div><div class="meta"><span>'+esc(placeName(l.from))+' → '+esc(placeName(l.to))+'</span><span class="num">'+l.km.toFixed(1)+' km</span><span class="num">'+peso(l.fare)+'</span></div></div>';
          });
          h+='</div><div class="meta" style="margin-top:10px"><span class="num">'+o.km.toFixed(1)+' km total</span></div></div>';
        });
        h+='</div>';
      }else{
        h+='<div class="card empty">No sample route connects these places'+(S.mode!=="all"?" for this transport type":"")+'. Try another filter or different stops.</div>';
      }
    }
  }else{
    h+='<div class="head"><h3>All sample routes</h3><span class="small muted">Choose both places to see fares</span></div><div class="list">';
    ROUTES.filter(function(r){return S.mode==="all"||r.mode===S.mode}).forEach(function(r){
      var a=r.stops[0][0],b=r.stops[r.stops.length-1][0];
      h+=routeCard({r:r,from:a,to:b,km:kmBetween(r,a,b),fare:fare(r.mode,kmBetween(r,a,b))},false);
    });
    h+='</div>';
  }
  h+=sampleNotice('Fares are estimates from editable sample rates. Real fares and routes may differ.');
  $("#p-routes").innerHTML=h;
}

function fareRows(km,pax){
  var h="";
  MODE_KEYS.forEach(function(k){
    var f=fare(k,km);
    h+='<div class="item"><span class="rico '+MODES[k].c+'" style="width:40px;height:40px">'+IC[k]+'</span><div class="grow"><b>'+MODES[k].name+'</b><span class="small muted">'+rateText(k)+'</span></div><div class="fare num">'+peso(f*pax)+(pax>1?'<small>'+peso(f)+' each</small>':'')+'</div></div>';
  });
  return h;
}
function renderFares(){
  var km=Number(S.calc.km)||0,pax=Math.max(1,Math.floor(Number(S.calc.pax)||1));
  var h='<div><h2>Fare calculator</h2><p class="muted">Estimate what a trip costs by distance.</p></div>';
  h+='<div class="card"><div class="row"><div class="field"><label for="calc-km">Distance (km)</label><input id="calc-km" type="number" inputmode="decimal" min="0" step="0.1" value="'+esc(S.calc.km)+'" data-bind="calckm"></div>'+
     '<div class="field"><label for="calc-pax">Passengers</label><input id="calc-pax" type="number" inputmode="numeric" min="1" max="20" step="1" value="'+esc(S.calc.pax)+'" data-bind="calcpax"></div></div>'+
     '<div class="row" style="margin-top:12px;align-items:center"><button class="btn sm" data-act="usekm">Use distance from my trip</button><span class="small muted">Fare type: '+FARE_TYPES[S.profile.fareType]+' · <a href="#profile" style="color:var(--accent)">change</a></span></div></div>';
  h+='<div class="list" id="fare-results">'+fareRows(km,pax)+'</div>';
  h+='<div><h3 style="margin-bottom:10px">Fare examples</h3><div class="tablewrap"><table><thead><tr><th>Distance</th>'+MODE_KEYS.map(function(k){return "<th>"+MODES[k].name+"</th>"}).join("")+'</tr></thead><tbody>';
  [1,2,4,6,10,15,20,30].forEach(function(d){h+='<tr><td>'+d+' km</td>'+MODE_KEYS.map(function(k){return "<td>"+peso(fare(k,d))+"</td>"}).join("")+"</tr>"});
  h+='</tbody></table></div></div>';
  h+=sampleNotice('These use sample rates, rounded to the nearest 25 centavos. You can change every rate in Profile. Tricycle fares are often agreed locally, so treat them as a rough guide.');
  $("#p-fares").innerHTML=h;
}

function renderSaved(){
  var h='<div><h2>Saved destinations</h2><p class="muted">Jump straight to the places you go often.</p></div>';
  h+='<div class="list">';
  if(!S.saved.length)h+='<div class="card empty">Nothing saved yet. Add a place below.</div>';
  S.saved.forEach(function(s){
    h+='<div class="item"><span class="rico c-modern" style="width:40px;height:40px">'+IC.pin+'</span><div class="grow"><b>'+esc(s.label)+(s.sample?'<span class="ex">Example</span>':"")+'</b><span class="small muted">'+esc(placeName(s.place))+'</span></div>'+
      '<div class="chips"><button class="btn sm primary" data-act="gohere" data-id="'+s.id+'">Go here</button><button class="btn sm" data-act="fromhere" data-id="'+s.id+'">From here</button><button class="btn sm ghost" data-act="rmsaved" data-id="'+s.id+'" aria-label="Remove '+esc(s.label)+'">Remove</button></div></div>';
  });
  h+='</div>';
  h+='<form class="card" data-form="saved"><h3 style="margin-bottom:12px">Add a destination</h3><div class="row"><div class="field"><label for="sv-label">Name</label><input id="sv-label" type="text" maxlength="30" placeholder="Home, Church, Market"></div>'+
     '<div class="field"><label for="sv-place">Place</label><select id="sv-place">'+PLACES.map(function(p){return '<option value="'+p.id+'">'+esc(p.name)+'</option>'}).join("")+'</select></div></div>'+
     '<div style="margin-top:12px"><button class="btn primary" type="submit">Save destination</button></div></form>';
  $("#p-saved").innerHTML=h;
}

function renderBudget(){
  var tk=todayKey(),t=spentOn(tk),b=Number(S.profile.budget)||0,pct=b>0?Math.min(100,t/b*100):0;
  var cls=t>b?"over":(t>b*0.8?"warn":"");
  var days=[];for(var i=6;i>=0;i--){var d=new Date(Date.now()-i*DAY);days.push({k:dkey(d),l:d.toLocaleDateString("en-PH",{weekday:"short"}),v:spentOn(dkey(d))})}
  var max=Math.max(b,1);days.forEach(function(d){if(d.v>max)max=d.v});
  var week=days.reduce(function(a,d){return a+d.v},0);
  var month=S.expenses.reduce(function(a,e){return e.date.slice(0,7)===tk.slice(0,7)?a+Number(e.amount):a},0);
  var h='<div><h2>Daily expenses</h2><p class="muted">Track what you spend on getting around.</p></div>';
  h+='<div class="card"><div class="lbl">Today</div><div class="big num">'+peso(t)+'</div><div class="meter" style="margin:10px 0 6px"><i class="'+cls+'" style="width:'+pct+'%"></i></div><div class="small muted num">'+(t>b?peso(t-b)+" over":peso(b-t)+" left")+' of your '+peso(b)+' daily budget</div></div>';
  h+='<div class="card"><div class="head"><h3>Last 7 days</h3><span class="small muted num">Total '+peso(week)+'</span></div><div class="chartwrap" style="margin-top:6px"><div class="chart">';
  days.forEach(function(d){
    var hh=Math.max(0,d.v/max*100);
    h+='<div class="col"><span class="v">'+(d.v?Math.round(d.v):"")+'</span><div class="bar'+(d.k===tk?" today":"")+'" style="height:'+hh*0.78+'%" title="'+esc(d.l)+": "+peso(d.v)+'"></div></div>';
  });
  h+='</div>';
  if(b>0)h+='<div class="goal" style="bottom:calc('+(b/max*100*0.78)+'% + 0px)"><span>Budget '+Math.round(b)+'</span></div>';
  h+='</div><div class="days">'+days.map(function(d){return "<span>"+esc(d.l)+"</span>"}).join("")+'</div>';
  h+='<div class="meta" style="margin-top:10px"><span class="num">This month: '+peso(month)+'</span></div></div>';
  h+='<form class="card" data-form="expense"><h3 style="margin-bottom:12px">Add an expense</h3><div class="row">'+
     '<div class="field"><label for="b-date">Date</label><input id="b-date" type="date" value="'+tk+'" max="'+tk+'"></div>'+
     '<div class="field"><label for="b-mode">Transport</label><select id="b-mode">'+Object.keys(MODES).map(function(k){return '<option value="'+k+'">'+MODES[k].name+'</option>'}).join("")+'</select></div></div>'+
     '<div class="row" style="margin-top:10px"><div class="field"><label for="b-amt">Amount (₱)</label><input id="b-amt" type="number" inputmode="decimal" min="0" step="0.25" placeholder="0.00"></div>'+
     '<div class="field"><label for="b-note">Note</label><input id="b-note" type="text" maxlength="60" placeholder="Where to?"></div></div>'+
     '<div style="margin-top:12px"><button class="btn primary" type="submit">Add expense</button></div></form>';
  var rows=S.expenses.slice().sort(function(x,y){return x.date<y.date?1:x.date>y.date?-1:0}).slice(0,25);
  var hasSample=S.expenses.some(function(e){return e.sample});
  h+='<div class="head"><h3>Recent trips</h3>'+(hasSample?'<button class="btn ghost sm" data-act="clearsamples">Clear example entries</button>':"")+'</div><div class="list">';
  if(!rows.length)h+='<div class="card empty">No expenses yet. Add one above or log a trip from the Routes tab.</div>';
  rows.forEach(function(e){
    var m=MODES[e.mode]||MODES.other,lab=e.date===tk?"Today":(e.date===daysAgo(1)?"Yesterday":e.date);
    h+='<div class="item"><span class="rico '+m.c+'" style="width:40px;height:40px">'+IC[MODES[e.mode]?e.mode:"other"]+'</span><div class="grow"><b>'+esc(e.note||m.name)+(e.sample?'<span class="ex">Example</span>':"")+'</b><span class="small muted">'+esc(lab)+' · '+m.name+'</span></div><span class="fare num" style="font-size:1.1rem">'+peso(Number(e.amount))+'</span><button class="btn ghost sm" data-act="rmexp" data-id="'+e.id+'" aria-label="Delete expense">Delete</button></div>';
  });
  h+='</div>';
  $("#p-budget").innerHTML=h;
}

var STATUS=[
  ["Home dashboard","ok","Built","Trip planner, categories, today’s spend"],
  ["Transport categories","ok","Built","Jeepney, modern jeepney, tricycle, bus"],
  ["Route search and filters","part","Built · sample routes","Search by origin and destination, filter by type"],
  ["Fare examples","part","Built · sample rates","Rates can be edited below"],
  ["Budget tracker","ok","Built · this device","Saved in this browser only"],
  ["Saved destinations","ok","Built · this device","Saved in this browser only"],
  ["Real GPS tracking","no","Not included","Needs live GPS feeds from transport operators"],
  ["Database and login","ok","Built \u00B7 Flask + SQLite","Accounts sync saved places and expenses"],
  ["Verified Sorsogon routes","no","Not verified","Needs official route and fare data from the city or operators"]
];
function renderProfile(){
  var h='<div><h2>Profile and settings</h2><p class="muted">'+(user?"Synced to your account.":"Your details stay in this browser unless you sign in.")+'</p></div>'+authCard();
  h+='<div class="card"><div class="row"><div class="field"><label for="pname">Name</label><input id="pname" type="text" maxlength="30" value="'+esc(S.profile.name)+'" data-bind="pname" placeholder="Optional"></div>'+
     '<div class="field"><label for="pbudget">Daily budget (₱)</label><input id="pbudget" type="number" inputmode="decimal" min="0" step="5" value="'+esc(S.profile.budget)+'" data-bind="pbudget"></div></div>'+
     '<div class="row" style="margin-top:10px"><div class="field"><label for="pfare">Fare type</label><select id="pfare" data-bind="pfare">'+Object.keys(FARE_TYPES).map(function(k){return '<option value="'+k+'"'+(S.profile.fareType===k?" selected":"")+'>'+FARE_TYPES[k]+'</option>'}).join("")+'</select></div></div></div>';
  h+='<div class="card"><div class="head"><h3>Sample fare rates</h3><button class="btn ghost sm" data-act="resetrates">Reset</button></div><p class="small muted" style="margin:6px 0 12px">Fare = base fare, plus the per-km rate for each km after the base distance.</p><div class="rates"><span class="h">Mode</span><span class="h">Base ₱</span><span class="h">Base km</span><span class="h">₱ / km</span>';
  MODE_KEYS.forEach(function(k){
    h+='<span><b>'+MODES[k].name+'</b></span>';
    ["base","baseKm","perKm"].forEach(function(f){h+='<input type="number" inputmode="decimal" min="0" step="0.05" aria-label="'+MODES[k].name+' '+f+'" value="'+S.rates[k][f]+'" data-rate="'+k+"."+f+'">'});
  });
  h+='</div></div>';
  h+='<div class="card"><h3 style="margin-bottom:4px">Status of this version</h3><p class="small muted">What works today and what needs real data.</p><div class="status" style="margin-top:8px">';
  STATUS.forEach(function(s){h+='<div class="s"><b>'+s[0]+'</b><span class="st '+s[1]+'">'+s[2]+'</span><small>'+s[3]+'</small></div>'});
  h+='</div></div>';
  h+='<div class="card flat"><h3 style="margin-bottom:6px">Reset data</h3><p class="small muted" style="margin-bottom:12px">Removes your expenses, saved places and settings from this browser (and from your account if you are signed in) and brings back the examples.</p>';
  h+=confirmReset?'<div class="row"><button class="btn danger" data-act="doreset">Yes, reset everything</button><button class="btn ghost" data-act="cancelreset">Cancel</button></div>':'<button class="btn danger" data-act="askreset">Reset my data</button>';
  h+='</div>';
  $("#p-profile").innerHTML=h;
}

/* ---------- navigation ---------- */
var VIEWS={home:renderHome,routes:renderRoutes,fares:renderFares,saved:renderSaved,budget:renderBudget,profile:renderProfile};
var DOCK=[["home","Home","home"],["routes","Routes","route"],["fares","Fares","fare"],["saved","Saved","pin"],["budget","Expenses","wallet"]];
$("#dock").innerHTML=DOCK.map(function(d){return '<button data-go="'+d[0]+'" data-dock="'+d[0]+'">'+IC[d[2]]+'<span>'+d[1]+'</span></button>'}).join("");
var tab="home";
function show(){
  var h=(location.hash||"").replace("#","");if(!VIEWS[h])h="home";tab=h;
  Object.keys(VIEWS).forEach(function(k){$("#p-"+k).hidden=k!==h});
  document.querySelectorAll("[data-dock]").forEach(function(b){if(b.dataset.dock===h)b.setAttribute("aria-current","page");else b.removeAttribute("aria-current")});
  VIEWS[h]();window.scrollTo(0,0);
}
function go(t){if(location.hash==="#"+t)show();else location.hash=t}
function rerender(){VIEWS[tab]()}
window.addEventListener("hashchange",show);

/* ---------- events ---------- */
document.addEventListener("click",function(ev){
  var g=ev.target.closest("[data-go]");if(g){go(g.dataset.go);return}
  var el=ev.target.closest("[data-act]");if(!el)return;
  var act=el.dataset.act,id=el.dataset.id;
  if(act==="swap"){var x=S.from;S.from=S.to;S.to=x;save();rerender()}
  else if(act==="find"){if(!S.from||!S.to){toast("Choose both an origin and a destination")}if(S.from&&S.to&&S.from===S.to){toast("Origin and destination are the same")}go("routes")}
  else if(act==="mode"){S.mode=el.dataset.mode;save();if(tab==="routes")rerender();else go("routes")}
  else if(act==="pickdest"){S.to=el.dataset.place;save();rerender();toast("Destination set to "+placeName(S.to))}
  else if(act==="savedest"){
    if(S.saved.some(function(s){return s.place===S.to})){toast("Already in your saved destinations");return}
    S.saved.push({id:uid(),label:placeName(S.to),place:S.to});save();toast("Saved "+placeName(S.to));
  }
  else if(act==="log"){
    var r=ROUTES.filter(function(q){return q.id===el.dataset.r})[0],km=kmBetween(r,el.dataset.a,el.dataset.b);
    addExpense({mode:r.mode,amount:fare(r.mode,km),note:placeName(el.dataset.a)+" to "+placeName(el.dataset.b)});
    toast("Added "+peso(fare(r.mode,km))+" to today’s expenses");
  }
  else if(act==="usekm"){
    if(S.from&&S.to&&S.from!==S.to){var d=direct(S.from,S.to,"all");if(d.length){S.calc.km=Math.min.apply(null,d.map(function(x){return x.km}));save();rerender();return}}
    toast("Pick an origin and destination in Routes first");
  }
  else if(act==="gohere"||act==="fromhere"){
    var s=S.saved.filter(function(q){return q.id===id})[0];if(!s)return;
    if(act==="gohere")S.to=s.place;else S.from=s.place;save();go("routes");
  }
  else if(act==="rmsaved"){S.saved=S.saved.filter(function(q){return q.id!==id});save();rerender()}
  else if(act==="rmexp"){S.expenses=S.expenses.filter(function(q){return q.id!==id});save();rerender()}
  else if(act==="clearsamples"){S.expenses=S.expenses.filter(function(q){return !q.sample});save();rerender()}
  else if(act==="logout"){logout()}
  else if(act==="resetrates"){S.rates=clone(DEFAULT_RATES);save();rerender()}
  else if(act==="askreset"){confirmReset=true;rerender()}
  else if(act==="cancelreset"){confirmReset=false;rerender()}
  else if(act==="doreset"){S=freshState();confirmReset=false;save();rerender();toast("Data reset")}
});
document.addEventListener("change",function(ev){
  var t=ev.target,b=t.dataset.bind;
  if(b==="from"||b==="to"){S[b]=t.value;save();if(tab!=="home")rerender()}
  else if(b==="sort"){S.sort=t.value;save();rerender()}
  else if(b==="pname"){S.profile.name=t.value.trim();save()}
  else if(b==="pbudget"){S.profile.budget=Math.max(0,Number(t.value)||0);save()}
  else if(b==="pfare"){S.profile.fareType=t.value;save()}
  else if(t.dataset.rate){var p=t.dataset.rate.split(".");S.rates[p[0]][p[1]]=Math.max(0,Number(t.value)||0);save()}
});
document.addEventListener("input",function(ev){
  var t=ev.target,b=t.dataset.bind;
  if(b==="calckm"||b==="calcpax"){
    if(b==="calckm")S.calc.km=t.value;else S.calc.pax=t.value;save();
    var km=Number(S.calc.km)||0,pax=Math.max(1,Math.floor(Number(S.calc.pax)||1));
    $("#fare-results").innerHTML=fareRows(km,pax);
  }
});
document.addEventListener("submit",function(ev){
  var f=ev.target.closest("[data-form]");if(!f)return;ev.preventDefault();
  if(f.dataset.form==="auth"){
    auth((ev.submitter&&ev.submitter.dataset.mode)||"login");return;
  }
  if(f.dataset.form==="saved"){
    var label=$("#sv-label").value.trim();if(!label){toast("Give the destination a name");return}
    S.saved.push({id:uid(),label:label,place:$("#sv-place").value});save();rerender();toast("Saved "+label);
  }else if(f.dataset.form==="expense"){
    var amt=Number($("#b-amt").value);if(!(amt>0)){toast("Enter an amount greater than 0");return}
    addExpense({date:$("#b-date").value||todayKey(),mode:$("#b-mode").value,amount:amt,note:$("#b-note").value.trim()});
    rerender();toast("Expense added");
  }
});
show();
loadMe();
})();
