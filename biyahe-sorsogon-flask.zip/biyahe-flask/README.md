# Biyahe Sorsogon (Flask + SQLite)

A mobile-first commute guide for Sorsogon City: find jeepney, modern jeepney, tricycle and bus routes, estimate fares, save destinations and track daily transport spending.

> **All route, stop, distance and fare data is sample data.** It is not verified and no vehicle is tracked live.

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
flask --app app run --debug
```

Open http://127.0.0.1:5000. The SQLite database is created automatically in `instance/biyahe.db` on first run.

## Feature status

| Feature | Status |
| --- | --- |
| Home dashboard with origin and destination | Built |
| Transport categories | Built |
| Route search, filters, one-transfer suggestions | Built (sample routes) |
| Fare calculator and fare examples | Built (sample, editable rates) |
| Saved destinations | Built |
| Daily transportation expense tracker | Built |
| Profile and settings | Built |
| Database and login | Built (SQLite, optional accounts) |
| Real GPS tracking | Not included (needs operator GPS feeds) |
| Verified Sorsogon routes | Not included (needs official data) |

Without an account, saved places, expenses and settings stay in the browser (`localStorage`). After signing in, they are stored in the database and sync across devices.

## Project structure

```
app.py                  Flask app, API, database helpers, CLI commands
schema.sql              SQLite tables
data/sample_data.json   SAMPLE places, routes, fare rates (seeded on first run)
templates/index.html    page shell, receives the reference data from the database
static/css/styles.css   design tokens, light and dark themes, components
static/js/app.js        UI, fare logic, localStorage, account sync
tests/test_app.py       API tests
```

## Database

| Table | Purpose |
| --- | --- |
| `places`, `routes`, `route_stops`, `fare_rates` | Reference data, loaded from `data/sample_data.json` |
| `users` | Email, name, password hash, fare type, daily budget |
| `user_rates` | Per-user fare rate overrides |
| `saved_places` | Saved destinations per user |
| `expenses` | Transport expenses per user |

Commands:

```bash
flask --app app init-db     # create tables and seed sample data if empty
flask --app app reset-db    # delete the database and recreate it (removes all accounts)
```

To load real routes later, replace the data in `data/sample_data.json` and run `reset-db`, or insert rows into the reference tables directly. Route stops are `[place_id, km from the first stop]`.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/data` | Places, routes and default fare rates |
| POST | `/api/register` | `{email, password, name?, state?}` creates an account and signs in |
| POST | `/api/login` | `{email, password}` |
| POST | `/api/logout` | Ends the session |
| GET | `/api/me` | Current user and saved state, or `{user: null}` |
| PUT | `/api/me/state` | Replaces profile, rates, saved places and expenses for the signed-in user |

All write endpoints require a JSON body. Input is validated on the server (dates, amounts, modes, place ids, lengths).

## Tests

```bash
python3 -m unittest tests/test_app.py
```

## Before deploying

- Set a fixed `SECRET_KEY` environment variable (otherwise one is generated in `instance/secret_key`).
- Serve over HTTPS and set `SESSION_COOKIE_SECURE=1`.
- Run with a production server such as `gunicorn app:app`, not the Flask debug server.
- Add rate limiting to `/api/login` and `/api/register` (for example Flask-Limiter).
- Back up `instance/biyahe.db`, or move to PostgreSQL if you need more than a single server.

## Roadmap

- Verified routes and fares from the city and transport operators
- Admin tools for editing routes and fares
- Map view and live vehicle positions once GPS data is available
