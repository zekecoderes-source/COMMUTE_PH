"""Biyahe Sorsogon: Flask + SQLite backend.

Run:
    pip install -r requirements.txt
    flask --app app run --debug

All route, stop, distance and fare data seeded from data/sample_data.json is SAMPLE data.
"""
import json
import os
import re
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone

from flask import Flask, g, jsonify, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SEED_FILE = os.path.join(BASE_DIR, "data", "sample_data.json")
SCHEMA_FILE = os.path.join(BASE_DIR, "schema.sql")

app = Flask(__name__)
os.makedirs(app.instance_path, exist_ok=True)
DB_PATH = os.environ.get("BIYAHE_DB", os.path.join(app.instance_path, "biyahe.db"))


def _secret_key():
    key = os.environ.get("SECRET_KEY")
    if key:
        return key
    path = os.path.join(app.instance_path, "secret_key")
    if not os.path.exists(path):
        with open(path, "w") as fh:
            fh.write(secrets.token_hex(32))
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    with open(path) as fh:
        return fh.read().strip()


app.config.update(
    SECRET_KEY=_secret_key(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE") == "1",
    MAX_CONTENT_LENGTH=512 * 1024,
)

with open(SEED_FILE, encoding="utf-8") as fh:
    SEED = json.load(fh)
MODE_KEYS = SEED["MODE_KEYS"]                 # trad, modern, trike, bus
EXPENSE_MODES = set(MODE_KEYS) | {"other"}
FARE_TYPES = set(SEED["FARE_TYPES"])
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


# ---------- database ----------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    with open(SCHEMA_FILE, encoding="utf-8") as fh:
        db.executescript(fh.read())
    if db.execute("SELECT COUNT(*) FROM places").fetchone()[0] == 0:
        seed_reference_data(db)


def seed_reference_data(db):
    with db:
        for p in SEED["PLACES"]:
            db.execute("INSERT INTO places (id, name) VALUES (?, ?)", (p["id"], p["name"]))
        for r in SEED["ROUTES"]:
            db.execute(
                "INSERT INTO routes (id, mode, name, via, freq, hours) VALUES (?,?,?,?,?,?)",
                (r["id"], r["mode"], r["name"], r["via"], r["freq"], r["hours"]),
            )
            for seq, (place_id, km) in enumerate(r["stops"]):
                db.execute(
                    "INSERT INTO route_stops (route_id, seq, place_id, km) VALUES (?,?,?,?)",
                    (r["id"], seq, place_id, km),
                )
        for mode, rate in SEED["DEFAULT_RATES"].items():
            db.execute(
                "INSERT INTO fare_rates (mode, base, base_km, per_km) VALUES (?,?,?,?)",
                (mode, rate["base"], rate["baseKm"], rate["perKm"]),
            )


@app.cli.command("init-db")
def init_db_command():
    """Create tables and load the sample reference data."""
    init_db()
    print("Database ready at", DB_PATH)


@app.cli.command("reset-db")
def reset_db_command():
    """Delete the database file and recreate it (removes all accounts and data)."""
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
    print("Database reset at", DB_PATH)


# ---------- reference data ----------
def reference_data():
    db = get_db()
    places = [{"id": r["id"], "name": r["name"]} for r in db.execute("SELECT id, name FROM places ORDER BY rowid")]
    routes = []
    for r in db.execute("SELECT * FROM routes ORDER BY rowid"):
        stops = [
            [s["place_id"], s["km"]]
            for s in db.execute("SELECT place_id, km FROM route_stops WHERE route_id = ? ORDER BY seq", (r["id"],))
        ]
        routes.append({"id": r["id"], "mode": r["mode"], "name": r["name"], "via": r["via"],
                       "freq": r["freq"], "hours": r["hours"], "stops": stops})
    rates = {
        r["mode"]: {"base": r["base"], "baseKm": r["base_km"], "perKm": r["per_km"]}
        for r in db.execute("SELECT * FROM fare_rates")
    }
    return {"MODES": SEED["MODES"], "MODE_KEYS": MODE_KEYS, "FARE_TYPES": SEED["FARE_TYPES"],
            "PLACES": places, "ROUTES": routes, "DEFAULT_RATES": rates}


# ---------- per-user state ----------
def load_state(user_id):
    db = get_db()
    u = db.execute("SELECT name, fare_type, daily_budget FROM users WHERE id = ?", (user_id,)).fetchone()
    rates = {}
    for r in db.execute("SELECT * FROM user_rates WHERE user_id = ?", (user_id,)):
        rates[r["mode"]] = {"base": r["base"], "baseKm": r["base_km"], "perKm": r["per_km"]}
    saved = [
        {"id": r["id"], "label": r["label"], "place": r["place_id"]}
        for r in db.execute("SELECT * FROM saved_places WHERE user_id = ? ORDER BY rowid", (user_id,))
    ]
    expenses = [
        {"id": r["id"], "date": r["date"], "mode": r["mode"], "amount": r["amount"], "note": r["note"]}
        for r in db.execute("SELECT * FROM expenses WHERE user_id = ? ORDER BY date DESC, rowid DESC", (user_id,))
    ]
    return {
        "profile": {"name": u["name"], "fareType": u["fare_type"], "budget": u["daily_budget"]},
        "rates": rates, "saved": saved, "expenses": expenses,
    }


def _num(value, lo, hi, default=None):
    try:
        n = float(value)
    except (TypeError, ValueError):
        if default is not None:
            return default
        raise ValueError("Invalid number")
    if n != n or n < lo or n > hi:
        raise ValueError("Number out of range")
    return n


def save_state(user_id, st):
    """Validate and replace the user's profile, rates, saved places and expenses."""
    if not isinstance(st, dict):
        raise ValueError("Invalid data")
    db = get_db()
    place_ids = {r["id"] for r in db.execute("SELECT id FROM places")}

    prof = st.get("profile") or {}
    name = str(prof.get("name", ""))[:30].strip()
    fare_type = prof.get("fareType", "regular")
    if fare_type not in FARE_TYPES:
        fare_type = "regular"
    budget = _num(prof.get("budget", 150), 0, 100000, default=150)

    rates = []
    for mode, r in (st.get("rates") or {}).items():
        if mode in MODE_KEYS and isinstance(r, dict):
            rates.append((user_id, mode, _num(r.get("base"), 0, 10000, 0),
                          _num(r.get("baseKm"), 0, 1000, 0), _num(r.get("perKm"), 0, 10000, 0)))

    saved = []
    for s in (st.get("saved") or [])[:50]:
        label = str(s.get("label", "")).strip()[:30]
        if label and s.get("place") in place_ids:
            saved.append((user_id, str(s.get("id") or uuid.uuid4().hex)[:40], label, s["place"]))

    expenses = []
    for e in (st.get("expenses") or [])[:2000]:
        date = str(e.get("date", ""))
        if not DATE_RE.match(date):
            continue
        try:
            datetime.strptime(date, "%Y-%m-%d")
            amount = _num(e.get("amount"), 0.01, 100000)
        except ValueError:
            continue
        mode = e.get("mode")
        if mode not in EXPENSE_MODES:
            continue
        expenses.append((user_id, str(e.get("id") or uuid.uuid4().hex)[:40], date, mode, amount,
                         str(e.get("note", "")).strip()[:60]))

    with db:
        db.execute("UPDATE users SET name = ?, fare_type = ?, daily_budget = ? WHERE id = ?",
                   (name, fare_type, budget, user_id))
        for table in ("user_rates", "saved_places", "expenses"):
            db.execute("DELETE FROM " + table + " WHERE user_id = ?", (user_id,))
        db.executemany("INSERT INTO user_rates (user_id, mode, base, base_km, per_km) VALUES (?,?,?,?,?)", rates)
        db.executemany("INSERT OR REPLACE INTO saved_places (user_id, id, label, place_id) VALUES (?,?,?,?)", saved)
        db.executemany("INSERT OR REPLACE INTO expenses (user_id, id, date, mode, amount, note) VALUES (?,?,?,?,?,?)", expenses)


# ---------- helpers ----------
def error(message, status=400):
    return jsonify({"error": message}), status


def json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


def current_user():
    uid = session.get("uid")
    if not uid:
        return None
    return get_db().execute("SELECT id, email, name FROM users WHERE id = ?", (uid,)).fetchone()


def user_payload(row):
    return {"email": row["email"], "name": row["name"]}


# ---------- routes ----------
@app.get("/")
def index():
    return render_template("index.html", data=reference_data())


@app.get("/api/data")
def api_data():
    return jsonify(reference_data())


@app.get("/api/me")
def api_me():
    u = current_user()
    if not u:
        return jsonify({"user": None})
    return jsonify({"user": user_payload(u), "state": load_state(u["id"])})


@app.post("/api/register")
def api_register():
    body = json_body()
    if body is None:
        return error("Send JSON")
    email = str(body.get("email", "")).strip().lower()
    password = str(body.get("password", ""))
    name = str(body.get("name", "")).strip()[:30]
    if not EMAIL_RE.match(email) or len(email) > 254:
        return error("Enter a valid email address")
    if not 8 <= len(password) <= 128:
        return error("Password must be 8 to 128 characters")
    db = get_db()
    if db.execute("SELECT 1 FROM users WHERE email = ?", (email,)).fetchone():
        return error("An account with that email already exists", 409)
    with db:
        cur = db.execute(
            "INSERT INTO users (email, name, password_hash, created_at) VALUES (?,?,?,?)",
            (email, name, generate_password_hash(password), datetime.now(timezone.utc).isoformat()),
        )
    uid = cur.lastrowid
    if isinstance(body.get("state"), dict):
        try:
            save_state(uid, body["state"])
        except ValueError:
            pass
    session.clear()
    session["uid"] = uid
    return jsonify({"user": user_payload(current_user()), "state": load_state(uid)}), 201


@app.post("/api/login")
def api_login():
    body = json_body()
    if body is None:
        return error("Send JSON")
    email = str(body.get("email", "")).strip().lower()
    password = str(body.get("password", ""))
    row = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    if not row or not check_password_hash(row["password_hash"], password):
        return error("Incorrect email or password", 401)
    session.clear()
    session["uid"] = row["id"]
    return jsonify({"user": user_payload(row), "state": load_state(row["id"])})


@app.post("/api/logout")
def api_logout():
    session.clear()
    return jsonify({"ok": True})


@app.put("/api/me/state")
def api_save_state():
    u = current_user()
    if not u:
        return error("Sign in first", 401)
    body = json_body()
    if body is None:
        return error("Send JSON")
    try:
        save_state(u["id"], body)
    except ValueError as exc:
        return error(str(exc))
    return jsonify({"ok": True})


with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
