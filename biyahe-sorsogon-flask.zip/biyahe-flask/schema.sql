PRAGMA foreign_keys = ON;

-- Reference data (sample until verified data is loaded)
CREATE TABLE IF NOT EXISTS places (
    id   TEXT PRIMARY KEY,
    name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS routes (
    id    TEXT PRIMARY KEY,
    mode  TEXT NOT NULL CHECK (mode IN ('trad', 'modern', 'trike', 'bus')),
    name  TEXT NOT NULL,
    via   TEXT NOT NULL DEFAULT '',
    freq  TEXT NOT NULL DEFAULT '',
    hours TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS route_stops (
    route_id TEXT NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    seq      INTEGER NOT NULL,
    place_id TEXT NOT NULL REFERENCES places(id),
    km       REAL NOT NULL CHECK (km >= 0),
    PRIMARY KEY (route_id, seq)
);

CREATE TABLE IF NOT EXISTS fare_rates (
    mode    TEXT PRIMARY KEY CHECK (mode IN ('trad', 'modern', 'trike', 'bus')),
    base    REAL NOT NULL,
    base_km REAL NOT NULL,
    per_km  REAL NOT NULL
);

-- Accounts and per-user data
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    email         TEXT NOT NULL UNIQUE,
    name          TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    fare_type     TEXT NOT NULL DEFAULT 'regular',
    daily_budget  REAL NOT NULL DEFAULT 150,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_rates (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mode    TEXT NOT NULL,
    base    REAL NOT NULL,
    base_km REAL NOT NULL,
    per_km  REAL NOT NULL,
    PRIMARY KEY (user_id, mode)
);

CREATE TABLE IF NOT EXISTS saved_places (
    user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    id       TEXT NOT NULL,
    label    TEXT NOT NULL,
    place_id TEXT NOT NULL REFERENCES places(id),
    PRIMARY KEY (user_id, id)
);

CREATE TABLE IF NOT EXISTS expenses (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    id      TEXT NOT NULL,
    date    TEXT NOT NULL,
    mode    TEXT NOT NULL,
    amount  REAL NOT NULL CHECK (amount > 0),
    note    TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (user_id, id)
);

CREATE INDEX IF NOT EXISTS idx_expenses_user_date ON expenses (user_id, date);
