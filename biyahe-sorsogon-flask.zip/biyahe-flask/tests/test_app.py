import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_tmp = tempfile.mkdtemp()
os.environ["BIYAHE_DB"] = os.path.join(_tmp, "test.db")

import app as biyahe  # noqa: E402


class BiyaheTests(unittest.TestCase):
    def setUp(self):
        self.client = biyahe.app.test_client()

    def test_home_and_reference_data(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        data = self.client.get("/api/data").get_json()
        self.assertEqual(len(data["PLACES"]), 9)
        self.assertEqual(len(data["ROUTES"]), 8)
        self.assertEqual(data["ROUTES"][0]["stops"][0], ["bacon", 0])
        self.assertEqual(set(data["DEFAULT_RATES"]), {"trad", "modern", "trike", "bus"})

    def test_account_flow(self):
        c = self.client
        self.assertIsNone(c.get("/api/me").get_json()["user"])
        self.assertEqual(c.put("/api/me/state", json={}).status_code, 401)
        self.assertEqual(c.post("/api/register", json={"email": "bad", "password": "longenough"}).status_code, 400)
        self.assertEqual(c.post("/api/register", json={"email": "a@b.ph", "password": "short"}).status_code, 400)

        state = {
            "profile": {"name": "Ana", "fareType": "student", "budget": 120},
            "rates": {"trad": {"base": 14, "baseKm": 4, "perKm": 2}},
            "saved": [{"id": "x1", "label": "School", "place": "ssu"},
                      {"id": "x2", "label": "Nowhere", "place": "missing"}],
            "expenses": [{"id": "e1", "date": "2026-11-12", "mode": "trad", "amount": 13, "note": "Ride"},
                         {"id": "e2", "date": "2026-13-45", "mode": "trad", "amount": 13},
                         {"id": "e3", "date": "2026-11-12", "mode": "spaceship", "amount": 5},
                         {"id": "e4", "date": "2026-11-12", "mode": "bus", "amount": -4}],
        }
        r = c.post("/api/register", json={"email": "Ana@Example.PH", "password": "password123", "name": "Ana", "state": state})
        self.assertEqual(r.status_code, 201)
        got = r.get_json()["state"]
        self.assertEqual(r.get_json()["user"]["email"], "ana@example.ph")
        self.assertEqual(got["profile"]["fareType"], "student")
        self.assertEqual([s["label"] for s in got["saved"]], ["School"])
        self.assertEqual([e["id"] for e in got["expenses"]], ["e1"])
        self.assertEqual(got["rates"]["trad"]["perKm"], 2)

        self.assertEqual(c.post("/api/register", json={"email": "ana@example.ph", "password": "password123"}).status_code, 409)

        state["expenses"].append({"id": "e5", "date": "2026-11-11", "mode": "bus", "amount": 37, "note": "Gubat"})
        self.assertEqual(c.put("/api/me/state", json=state).status_code, 200)
        self.assertEqual(len(c.get("/api/me").get_json()["state"]["expenses"]), 2)

        c.post("/api/logout", json={})
        self.assertIsNone(c.get("/api/me").get_json()["user"])
        self.assertEqual(c.post("/api/login", json={"email": "ana@example.ph", "password": "wrong"}).status_code, 401)
        ok = c.post("/api/login", json={"email": "ana@example.ph", "password": "password123"})
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(len(ok.get_json()["state"]["expenses"]), 2)

    def test_users_are_isolated(self):
        a, b = biyahe.app.test_client(), biyahe.app.test_client()
        a.post("/api/register", json={"email": "one@x.ph", "password": "password123",
                                      "state": {"expenses": [{"id": "same", "date": "2026-11-12", "mode": "bus", "amount": 10}]}})
        b.post("/api/register", json={"email": "two@x.ph", "password": "password123"})
        self.assertEqual(b.get("/api/me").get_json()["state"]["expenses"], [])
        self.assertEqual(len(a.get("/api/me").get_json()["state"]["expenses"]), 1)

    def test_form_posts_rejected(self):
        r = self.client.post("/api/login", data={"email": "a@b.ph", "password": "x"})
        self.assertEqual(r.status_code, 400)


if __name__ == "__main__":
    unittest.main()
